﻿# ============================================================================
# CICADA orchestrator.ps1 - unsupervised PLAN -> BUILD -> VALIDATE -> REVIEW loop
# with git checkpointing (baseline / commit-per-task / rollback-on-blocked)
# and an end-of-run markdown digest.
#   New run:  .\manager\orchestrator.ps1 -Project <dir> -Objective "<goal>"
#   Resume:   .\manager\orchestrator.ps1 -Project <dir> -RunId <id>
#   No git:   add -NoGit
# ============================================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Project,
    [string]$Objective = "",
    [string]$PlanFile = "",
    [string]$PlanModel = "minimax/MiniMax-M3",
    [string]$ReviewModel = "minimax/MiniMax-M3",
    [string]$BuilderModel = "minimax/MiniMax-M2.7",
    [string]$BuilderAgent      = "build",
    [string]$PlanAgent         = "plan",
    [string]$ReviewAgent       = "review",
    [int]$MaxTaskRetries = 2,
    [int]$MaxCalls       = 50,
    [double]$MaxCost     = 0,
    [int64]$MaxTokens = 1000000,
    [string]$ModeLabel = "unsupervised",
    [switch]$NoGit,
    [int]$CallTimeoutSec = 1800,
    [int]$ValidationTimeoutSec = 120,
    [string]$RunId
)

$ErrorActionPreference = "Continue"
. (Join-Path $PSScriptRoot "engine.ps1")
# --- Telegram detail: prefix every run notification with the agent name ---
$script:SendCicadaTelegramCore = (Get-Item Function:\Send-CicadaTelegram).ScriptBlock
function Send-CicadaTelegram([string]$Message) {
    $prefix = ""
    if ($script:CicadaRunName) { $prefix = "[" + $script:CicadaRunName + "] " }
    & $script:SendCicadaTelegramCore ($prefix + $Message)
}
Repair-CicadaStaleRuns

if (-not (Test-Path $Project -PathType Container)) { Write-Error "Project not found: $Project"; exit 1 }
$Project = (Resolve-Path $Project).Path

# ---------- prompt contracts ----------

function Get-PlanPrompt {
    @"
You are the planning engine of an autonomous coding system.

Project directory: $Project
Objective: $Objective

Break the objective into a small number of concrete, independently implementable tasks, ordered so earlier tasks unblock later ones.

Respond with ONLY a JSON array. Each element is an object:
{"title":"short imperative task","files":["likely","paths"],"validate":"single command that proves the task works","risk":"low"}

Rules:
- Each task must be completable by one coding agent in one focused session.
- "files": best guess at the paths involved; saves the builder scanning the repo. Empty array if unknown.
- "validate": exactly ONE Windows PowerShell command, runnable from the project root, that exits 0 on success and non-zero on failure. Single line only - never chain commands with semicolons or && (they get mangled into broken commands). Patterns that work: type a.txt,b.txt,c.txt to check several files at once (comma-separated paths, no spaces after commas); findstr alpha a.txt to check content (exit 1 when not found); node check.js or npm test or powershell -File verify.ps1 for real suites. Empty string if no mechanical check exists.
- "risk": "high" for auth/security, secrets, destructive operations, concurrency, database migrations, public API changes, AND any task whose correct result depends on data you cannot verify locally (network fetches, credentials, external state). Everything else is "low".
- CAPABILITY ENVELOPE: builders have ONLY these tools - read, edit, bash, glob, grep, list, lsp. There is NO network, NO web access, NO credentials, and NO user available to answer questions. If any task needs a capability outside this envelope, do not plan around it: respond BLOCKED: <missing capability> instead of a JSON array.
- Granularity (IMPORTANT): if the objective names N distinct deliverables, emit exactly N tasks (or more, never fewer); never merge independently-validatable deliverables into one task. Use one task only when the objective is a single deliverable. Keep each task focused: one change plus its validation. Cap at 8 tasks per plan.
- Example. Objective: "Create a.txt containing alpha, and b.txt containing beta". Correct plan output:
[{"title":"Create a.txt containing alpha","files":["a.txt"],"validate":"type a.txt","risk":"low"},{"title":"Create b.txt containing beta","files":["b.txt"],"validate":"type b.txt","risk":"low"}]
- No prose. No markdown fences. JSON only.

If the objective is too unclear to plan, respond with: BLOCKED: <reason>
"@
}

function Get-BuildPrompt {
    param([string]$Task, [string]$FilesHint, [string]$ValidateHint, [int]$Attempt, [string]$Previous)
    $retryNote = ""
    if ($Attempt -gt 1 -and $Previous) { $retryNote = "`nThis is attempt $Attempt. The previous attempt was rejected with this feedback:`n$Previous`nFix the cited problems first.`n" }
    $filesLine = ""
    if ($FilesHint) { $filesLine = "`nLikely files: $FilesHint`n" }
    $valLine = ""
    if ($ValidateHint) { $valLine = "`nA suitable validation command is probably: $ValidateHint`n" }
    @"
You are the builder in an autonomous coding system. You work alone in the project directory.

Project: $Project
Overall objective: $Objective
Assigned task: $Task
$filesLine$valLine$retryNote
Rules:
- Inspect before editing; start from the likely files. Make the smallest correct change. Follow existing conventions. Do not modify unrelated files.
- If the task involves parsing or reading existing files or data, inspect a real sample before writing the parser; never invent the input format.
- Implement the task fully, then run the narrowest relevant validation and fix failures you caused.
- Do not stop at analysis or proposals: make the real changes.
- You have a limited number of tool steps; spend them deliberately: brief inspection, implementation, validation. Do not wander.
- Honesty: if a required tool is unavailable or denied, or you cannot obtain the real data or result, you MUST end with STATUS: BLOCKED and name what is missing. Never fabricate content, placeholder data, or results. A fabricated completion is worse than a blocker.

End your final message with EXACTLY this structure, one per line:
STATUS: COMPLETE
VALIDATION: <the single command you ran; must work in Windows PowerShell from the project root; empty if none>
RESULT: <one line: pass/fail + key output>
FILES: <comma-separated files you changed>

Or, if you cannot proceed:
STATUS: BLOCKED: <one-line reason>
"@
}

function Get-ReviewPrompt {
    param([string]$Task, [int]$Attempt, [string]$Report, [string]$ValEvidence)
    @"
You are the reviewer in an autonomous coding system.

Project: $Project
Objective: $Objective
Task: $Task
Attempt: $Attempt

Builder's final report:
---
$Report
---

Independent validation evidence gathered by the orchestrator:
$ValEvidence

You have read and bash tools - use them. Do not trust the report: open the files it claims changed and re-run the validation command yourself before deciding.

Decide the next action. Reply with exactly one verdict line:
NEXT                  - task genuinely complete and validated
RETRY: <what to fix>  - concrete problems; builder must retry
BLOCKED: <reason>     - human input required

NEXT requires ALL of: (1) every file in the FILES list exists and contains the claimed implementation; (2) the validation command exits 0 when YOU run it; (3) the report's RESULT matches what you observe. If any check fails, RETRY with specifics.
RETRY feedback must name the exact file or behavior that is wrong and the check that fails - the builder receives your text verbatim.
Use BLOCKED only when human input is required (ambiguity, missing capability, credentials).
"@
}

# ---------- supervised invocation ----------

function Invoke-Supervised {
param([hashtable]$CallArgs, [int]$TimeoutSec, [int]$WatchdogSec = 300)
$enginePath = Join-Path $PSScriptRoot "engine.ps1"
$guided = $false

while ($true) {
    if (-not $CallArgs.ContainsKey("LogPath") -or -not $CallArgs.LogPath) {
        if (-not (Test-Path $script:LogDir)) { New-Item -ItemType Directory -Force -Path $script:LogDir | Out-Null }
        $CallArgs = @{} + $CallArgs
        $CallArgs.LogPath = Join-Path $script:LogDir (([DateTime]::UtcNow.ToString("yyyyMMdd-HHmmss")) + "-" + (([string]$CallArgs.Title) -replace "[^\w\-]", "-") + ".jsonl")
    }
    $logPath = [string]$CallArgs.LogPath
    $job = Start-Job -ScriptBlock {
        param($eng, $a)
        . $eng
        Invoke-AgentWithFallback -CallArgs $a -FallbackModels @(Get-CicadaFallbackFor ([string]$a.Model)) -Seat ([string]$a.Agent)
    } -ArgumentList $enginePath, $CallArgs

    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    $lastBeat = Get-Date
    $stalled = $false
    while ($true) {
        $done = Wait-Job $job -Timeout 15
        if ($done) { break }
            $steerNote = $null
            if (Get-Command Get-CicadaSteeringFor -ErrorAction SilentlyContinue) { $steerNote = Get-CicadaSteeringFor $script:CicadaRunName }
            if ($steerNote) {
                Stop-Job $job -ErrorAction SilentlyContinue
                Remove-Job $job -Force -ErrorAction SilentlyContinue
                Stamp "INTERRUPT: operator note picked up mid-call - cancelling current attempt for planner consult"
                return [PSCustomObject]@{ SessionId=$null; Text=""; Tokens=$null; Cost=$null; FinishReason=$null; ExitCode=-1; ErrorName="OperatorInterrupt"; ErrorMessage="operator interrupt - note pending for planner"; LogPath=$logPath }
            }
        if (Test-Path $logPath) {
            $lw = (Get-Item $logPath).LastWriteTime
            if ($lw -gt $lastBeat) { $lastBeat = $lw }
        }
        if (-not $guided -and ((Get-Date) - $lastBeat).TotalSeconds -ge $WatchdogSec) { $stalled = $true; break }
        if ((Get-Date) -gt $deadline) { break }
    }

    if ($job.State -in @("Completed", "Failed", "Stopped") -and -not $stalled) {
        $out = Receive-Job $job
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        if ($out) { return $out }
        return [PSCustomObject]@{ SessionId=$null; Text=""; Tokens=$null; Cost=$null; FinishReason=$null; ExitCode=-1; ErrorName="JobFailed"; ErrorMessage="Job returned no result."; LogPath=$logPath }
    }

    Stop-Job $job -ErrorAction SilentlyContinue
    Remove-Job $job -Force -ErrorAction SilentlyContinue

    if ($stalled) {
        $guided = $true
        $sid = $null
        try {
            $sidLine = Select-String -Path $logPath -Pattern '"sessionID"\s*:\s*"([^"]+)"' | Select-Object -Last 1
            if ($sidLine) { $sid = $sidLine.Matches[0].Groups[1].Value }
        } catch {}
        $guideText = "The previous provider turn stalled and was interrupted. Resume exactly where you stopped: finish the current step first, then continue the task. Do not restart completed work."
        try {
            $gPrompt = "A coding worker stalled mid-task (no provider output for 5 minutes) and is being resumed. Task context: " + ([string]$CallArgs.Prompt).Substring(0, [Math]::Min(600, ([string]$CallArgs.Prompt).Length)) + "`n`nWrite 2-3 sentences of minimal resume guidance: what to do first, what to avoid redoing. No preamble."
            $gr = Invoke-AgentWithFallback -CallArgs @{ Project=[string]$CallArgs.Project; Prompt=$gPrompt; Model=(Get-CicadaFallbackFor ([string]$CallArgs.Model))[0]; Agent="plan"; Title=([string]$CallArgs.Title + "-watchdog") } -FallbackModels @([string]$CallArgs.Model) -Seat "watchdog"
            if ($gr -and $gr.Text) { $guideText = $gr.Text.Trim() }
        } catch {}
        Stamp ("WATCHDOG: no output for " + $WatchdogSec + "s - guided resume" + $(if ($sid) { " (session recovered)" } else { " (fresh session)" }))
        $CallArgs = @{} + $CallArgs
        if ($sid) { $CallArgs.SessionId = $sid } else { $CallArgs.SessionId = $null }
        $CallArgs.Prompt = "RESUME GUIDANCE: " + $guideText + " Original task: " + [string]$CallArgs.Prompt
        $CallArgs.LogPath = $null
        continue
    }

    return [PSCustomObject]@{ SessionId=$null; Text=""; Tokens=$null; Cost=$null; FinishReason=$null; ExitCode=-1; ErrorName="Timeout"; ErrorMessage="Call exceeded $TimeoutSec seconds."; LogPath=$logPath }
}
}

# ---------- deterministic validation gate (no model) ----------

function Invoke-Validation([string]$Command) {
    if (-not $Command) { return $null }
    $job = Start-Job -ScriptBlock {
        param($dir, $cmd)
        Set-Location $dir
        $code = $null
        $out = ""
        try {
            $out = Invoke-Expression $cmd 2>&1 | Out-String
            $code = $LASTEXITCODE
        } catch {
            $out = $_.Exception.Message
            $code = -1
        }
        if ($null -eq $code) { $code = 0 }
        return @{ code = $code; output = $out }
    } -ArgumentList $Project, $Command
    $done = Wait-Job $job -Timeout $ValidationTimeoutSec
    if ($done) {
        $r = Receive-Job $job
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        if ($null -eq $r) { return @{ code = -1; output = "validation job returned nothing" } }
        return $r
    }
    Stop-Job $job -ErrorAction SilentlyContinue
    Remove-Job $job -Force -ErrorAction SilentlyContinue
    return @{ code = -1; output = "validation timed out after $ValidationTimeoutSec seconds" }
}

function Read-BuildReport([string]$Text) {
    $rep = [ordered]@{ complete=$false; blocked=$false; blockReason=""; validation=""; result=""; files="" }
    if (-not $Text) { return [PSCustomObject]$rep }
    if ($Text -match "(?m)^STATUS:\s*COMPLETE") { $rep.complete = $true }
    if ($Text -match "(?m)^STATUS:\s*BLOCKED:?\s*(.*)$") { $rep.blocked = $true; $rep.blockReason = $Matches[1].Trim() }
    if ($Text -match "(?m)^VALIDATION:\s*(.+)$") { $rep.validation = $Matches[1].Trim() }
    if ($Text -match "(?m)^RESULT:\s*(.*)$") { $rep.result = $Matches[1].Trim() }
    if ($Text -match "(?m)^FILES:\s*(.+)$") { $rep.files = $Matches[1].Trim() }
    return [PSCustomObject]$rep
}

function Get-Tail([string]$s, [int]$max = 600) {
    if (-not $s) { return "" }
    $t = $s.Trim()
    if ($t.Length -le $max) { return $t }
    return $t.Substring($t.Length - $max)
}

function ConvertTo-Cell([string]$s) {
    if (-not $s) { return "" }
    return ($s -replace "\|", "/" -replace "\r?\n", " ").Trim()
}

# ---------- run helpers ----------

$run = $null

function Stop-CicadaRun([string]$why) {
    $run.status = "failed"
    Add-CicadaEvent -Run $run -Type "run_failed" -Data $why
    Write-Host "RUN FAILED: $why" -ForegroundColor Red
    exit 1
}

function Add-Totals($r) {
    $run.totals.calls += 1
    if ($r.Tokens) { $run.totals.tokens += [int64]$r.Tokens }
    if ($r.Cost)   { $run.totals.cost   += [double]$r.Cost }
}

function Stamp([string]$msg) { Write-Host "[$(Get-Date -Format HH:mm:ss)] $msg" }

# ---------- resume or new run ----------

if ($RunId) { $run = Get-CicadaRun -Id $RunId }
$resume = ($null -ne $run -and @($run.tasks).Count -gt 0)
if ($resume) { $run.tasks = @($run.tasks) }

if (-not $resume) {
    if ((-not $Objective -and -not $PlanFile)) { Write-Error "Objective is required for a new run."; exit 1 }
    $run = New-CicadaRun -Mode "unsupervised" -Project $Project -Objective $Objective
}
if (-not ($run.PSObject.Properties.Name -contains "totals")) {
    $run | Add-Member -NotePropertyName totals -NotePropertyValue ([PSCustomObject]@{ calls=0; tokens=0; cost=0.0 })
}
Save-CicadaRun -Run $run

$runName = Set-CicadaRunName $run.id
$run | Add-Member -NotePropertyName agentName -NotePropertyValue $runName -Force
Save-CicadaRun -Run $run
Stamp ("Agent name: " + $runName + "  (steer with: .\steer.ps1 -Name " + $runName + " <note>)")
Send-CicadaTelegram ("run started | " + (Split-Path -Leaf $Project) + " | " + $run.tasks.Count + " tasks | mode " + $run.mode)
# ---------- git checkpointing ----------

$gitOn = $false
$baseSha = $null
if ($resume -and ($run.PSObject.Properties.Name -contains "git") -and $run.git.baseline) {
    $gitOn = $true
    $baseSha = [string]$run.git.baseline
    Stamp "git checkpointing: on (baseline $baseSha)"
}
elseif (-not $NoGit -and (Get-Command git -ErrorAction SilentlyContinue)) {
    & git -C $Project rev-parse --is-inside-work-tree 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { & git -C $Project init 2>&1 | Out-Null }
    & git -C $Project config user.email 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        & git -C $Project config user.email "cicada@localhost" 2>&1 | Out-Null
        & git -C $Project config user.name "cicada" 2>&1 | Out-Null
    }
    $hasHead = $false
    & git -C $Project rev-parse HEAD 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { $hasHead = $true }
    $porc = & git -C $Project status --porcelain 2>&1 | Out-String
    if (-not $hasHead -or $porc.Trim()) {
        & git -C $Project add -A 2>&1 | Out-Null
        & git -C $Project commit --allow-empty -m "cicada: baseline (pre-run snapshot)" --quiet 2>&1 | Out-Null
    }
    & git -C $Project rev-parse --short HEAD 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        $gitOn = $true
        $baseSha = (& git -C $Project rev-parse --short HEAD 2>&1 | Out-String).Trim()
        $run | Add-Member -NotePropertyName git -NotePropertyValue ([PSCustomObject]@{ baseline = $baseSha }) -Force
        Add-CicadaEvent -Run $run -Type "git" -Data "checkpointing on; baseline $baseSha"
        Save-CicadaRun -Run $run
        Stamp "git checkpointing: on (baseline $baseSha)"
    }
}
if (-not $gitOn) { Stamp "git checkpointing: off" }

Stamp "Run $($run.id) | project: $Project"
Stamp "Operator controls: .\steer.ps1 <note> from another terminal (picked up within ~15s, cancels current attempt, planner consults) - or /interrupt <note> + Enter here (next checkpoint)"
if ($resume) { Stamp "Resuming from journal ($(@($run.tasks).Count) tasks)" }
if ($MaxCost -gt 0) { Stamp "Cost budget: `$$MaxCost" }
    if ($MaxTokens -gt 0) { Stamp "Token budget: $MaxTokens" }

# ---------- PLAN ----------

if (-not $resume) {
    Stamp "PLAN: decomposing objective..."
    $planItems = $null
if ($PlanFile) {
    $pf = $PlanFile
    if (-not [System.IO.Path]::IsPathRooted($pf)) { $pf = Join-Path $Project $pf }
    if (-not (Test-Path $pf)) { Write-Error "PlanFile not found: $pf"; exit 1 }
    Stamp ("PLAN: document-driven mode - reading tasks from " + (Split-Path -Leaf $pf) + " (no model decomposition)")
$doc = Get-Content $pf -Raw
$planItems = @()
$invalidPlanItems = @()
$blocks = [regex]::Matches($doc, '(?ms)^### \d+\.\s+(.+?)\r?\n(.*?)(?=^### \d+\.|\z)')

foreach ($blk in $blocks) {
    $btitle = $blk.Groups[1].Value.Trim()
    $bbody = $blk.Groups[2].Value

    $bfiles = @()
    $fm = [regex]::Match($bbody, '(?m)^-\s+\*\*Files:\*\*\s+(.+?)\s*$')
    if ($fm.Success) {
        $bfiles = @(
            $fm.Groups[1].Value -split ',' |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ }
        )
    }

    $bchange = ""
    $cm = [regex]::Match($bbody, '(?m)^-\s+\*\*Change:\*\*\s+(.+?)\s*$')
    if ($cm.Success) { $bchange = $cm.Groups[1].Value.Trim() }

    $bvalidate = ""
    $vm = [regex]::Match($bbody, '(?m)^-\s+\*\*Validation:\*\*\s+(.+?)\s*$')
    if ($vm.Success) { $bvalidate = $vm.Groups[1].Value.Trim().Trim([char]96).Trim() }

    $brisk = "low"
    $rm = [regex]::Match($bbody, '(?m)^-\s+\*\*Risk:\*\*\s+(\w+)')
    if ($rm.Success -and $rm.Groups[1].Value.Trim().ToLower() -eq "high") {
        $brisk = "high"
    }

    $bstepCount = 0
    $sm = [regex]::Match($bbody, '(?m)^-\s+\*\*Est\.\s*steps:\*\*\s*(\d+)\s*$')
    if ($sm.Success) { $bstepCount = [int]$sm.Groups[1].Value }

    $missing = @()
    if (-not $btitle) { $missing += "title" }
    if ($bfiles.Count -eq 0) { $missing += "Files" }
    if (-not $bchange) { $missing += "Change" }
    if (-not $bvalidate) { $missing += "Validation" }
    if ($bstepCount -lt 1 -or $bstepCount -gt 15) {
        $missing += "Est. steps (must be 1-15)"
    }
    if (($btitle.Length + $bchange.Length) -gt 900) {
        $missing += "task is too large (title + Change exceeds 900 characters)"
    }

    if ($missing.Count -gt 0) {
        $invalidPlanItems += ("'" + $btitle + "': missing/invalid " + ($missing -join ", "))
        continue
    }

    # Preserve the actual instruction. The old parser silently threw
    # away the Change field and sent only the short title to the builder.
    $planItems += [PSCustomObject]@{
        title    = $btitle + ": " + $bchange
        files    = $bfiles
        validate = $bvalidate
        risk     = $brisk
    }
}

if ($blocks.Count -eq 0) {
    # flat tokenprompt format fallback: "N. imperative | Files: ... | Prove: `...`"
    $delivIdx = $doc.IndexOf("## Deliverables")
    $searchFrom = 0
    if ($delivIdx -ge 0) { $searchFrom = $delivIdx }
    $flatMatches = [regex]::Matches($doc.Substring($searchFrom), '(?m)^(\d+)\.\s+(.+?)\s*$')
    if ($flatMatches.Count -eq 0) { Write-Error "PlanFile had no numbered deliverables (contract '### N.' or flat 'N. ... | Prove:'): $pf"; exit 1 }
    Stamp ("PLAN: flat tokenprompt format detected - " + $flatMatches.Count + " items")
    foreach ($lm in $flatMatches) {
        $line = $lm.Groups[2].Value.Trim()
        $bfiles = @()
        $fm = [regex]::Match($line, '\|\s*Files:\s*([^|]+)')
        if ($fm.Success) { $bfiles = @(($fm.Groups[1].Value -replace [char]96, '') -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
        $bvalidate = ""
        $vm = [regex]::Match($line, '\|\s*Prove:\s*`([^`]+)`')
        if ($vm.Success) { $bvalidate = $vm.Groups[1].Value }
        $btitle = ($line -split '\|', 2)[0].Trim()
        $planItems += [PSCustomObject]@{ title = $btitle; files = $bfiles; validate = $bvalidate; risk = "low" }
    }
}
if ($invalidPlanItems.Count -gt 0) {
    Write-Error ("PLAN.md task is malformed. No builders were started. " + ($invalidPlanItems -join " | "))
    exit 1
}
if ($planItems.Count -eq 0) {
    Write-Error "PlanFile yielded no executable tasks: $pf"
    exit 1
}

if (-not $Objective) {
    $Objective = "execute the plan in " + $pf + " - each numbered item is one task"
}
Stamp ("PLAN: document yielded " + $planItems.Count + " tasks")
}
    $planSession = $null
    for ($pa = 1; $pa -le 2 -and -not $planItems; $pa++) {
        $planPromptText = Get-PlanPrompt
        if ($pa -gt 1) { $planPromptText += "`nIMPORTANT: your previous reply contained no usable JSON task array. Respond with ONLY the JSON array now, no thinking." }
        $r = Invoke-Supervised -CallArgs @{ Project=$Project; Prompt=$planPromptText; Model=$PlanModel; Agent=$PlanAgent; Title=($run.id + "-plan" + $pa) } -TimeoutSec $CallTimeoutSec
        Add-Totals $r
    if ($r.SessionId) { $planSession = $r.SessionId }
        if ($r.ExitCode -ne 0) { Stamp ("PLAN: attempt " + $pa + " call failed (exit " + $r.ExitCode + ") log=" + $r.LogPath); continue }
        $planText = $r.Text
        if (-not $planText -and $r.RawText) { $planText = $r.RawText }
        if (-not $planText) { Stamp ("PLAN: attempt " + $pa + " returned empty text"); continue }
        if ($planText -match "BLOCKED:") { Stop-CicadaRun "planner blocked: $planText" }
        $m = [regex]::Match($planText, "(?s)\[.*\]")
        $okPlan = $false
        if ($m.Success) { try { $planItems = @($m.Value | ConvertFrom-Json); $okPlan = $true } catch { $okPlan = $false } }
        if (-not $okPlan) {
            $s0 = $planText.IndexOf("[")
            $e0 = $planText.LastIndexOf("}")
            if ($s0 -ge 0 -and $e0 -gt $s0) { try { $salv = $planText.Substring($s0, $e0 - $s0 + 1) + "]"; $planItems = @($salv | ConvertFrom-Json); $okPlan = $true; Stamp "PLAN: salvaged truncated plan JSON (closed after last complete task)" } catch { $planItems = $null } }
        }
        if ($okPlan -and $planItems -and $planItems.Count -gt 0) { if ($pa -gt 1) { Stamp ("PLAN: attempt " + $pa + " produced a task array") }; break }
        $planItems = $null
    $planSession = $null
        Stamp ("PLAN: attempt " + $pa + " returned no usable task array")
    }
    if (-not $planItems) { Stop-CicadaRun "planner returned no usable task list after 2 attempts (last log: $($r.LogPath))" }
    $tasks = @(); $i = 1
    foreach ($t in $planItems) {
        if ($t -is [string]) {
            $tasks += [PSCustomObject]@{ n=$i; title=$t; files=@(); validate=""; risk="low"; status="pending"; attempts=0; session=$null; report=$null; verdict=$null; filesChanged="" }
        } else {
            $files = @()
            if ($t.files) { $files = @($t.files | ForEach-Object { [string]$_ }) }
            $risk = ([string]$t.risk).ToLower()
            if ($risk -ne "high") { $risk = "low" }
            $tasks += [PSCustomObject]@{ n=$i; title=[string]$t.title; files=$files; validate=[string]$t.validate; risk=$risk; status="pending"; attempts=0; session=$null; report=$null; verdict=$null; filesChanged="" }
        }
        $i++
    }
    $run.tasks = $tasks
    Add-CicadaEvent -Run $run -Type "plan" -Data ([string]::Join(" | ", @($tasks | ForEach-Object { $_.title })))
    Save-CicadaRun -Run $run
    # merge-detector: one paragraph-length task = probable contract violation -> one enforcement round
if ($tasks.Count -eq 1 -and $planSession -and [string]$tasks[0].title -and ([string]$tasks[0].title).Length -gt 200) {
    Stamp "PLAN: single paragraph-length task detected - enforcing the granularity contract"
    $dr = Invoke-Supervised -CallArgs @{ Project=$Project; Prompt="CONTRACT VIOLATION: you merged multiple deliverables into one task. Return the JSON array again with ONE TASK PER DELIVERABLE. Same schema, same fields. No prose, just the array."; Model=$PlanModel; Agent=$PlanAgent; SessionId=$planSession; Title=($run.id + "-planfix") } -TimeoutSec $CallTimeoutSec
    Add-Totals $dr
    Add-CicadaEvent -Run $run -Type "plan_enforce" -Data "granularity enforcement round"
    $fixItems = $null
    if ($dr.ExitCode -eq 0 -and $dr.Text -and $dr.Text.Contains("[") -and $dr.Text.Contains('"title"')) {
        $fp = $dr.Text.Substring($dr.Text.IndexOf("["))
        try { $fixItems = @($fp | ConvertFrom-Json) } catch {
            $lc = $fp.LastIndexOf("}")
            if ($lc -gt 0) { try { $fixItems = @(($fp.Substring(0, $lc + 1) + "]") | ConvertFrom-Json) } catch { $fixItems = $null } }
        }
    }
    if ($fixItems -and $fixItems.Count -gt 1) {
        $tasks = @(); $i = 1
        foreach ($t in $fixItems) {
            if ($t -is [string]) { $tasks += [PSCustomObject]@{ n=$i; title=$t; files=@(); validate=""; risk="low"; status="pending"; attempts=0; session=$null; report=$null; verdict=$null; filesChanged="" } }
            else {
                $files = @(); if ($t.files) { $files = @($t.files | ForEach-Object { [string]$_ }) }
                $risk = ([string]$t.risk).ToLower(); if ($risk -ne "high") { $risk = "low" }
                $tasks += [PSCustomObject]@{ n=$i; title=[string]$t.title; files=$files; validate=[string]$t.validate; risk=$risk; status="pending"; attempts=0; session=$null; report=$null; verdict=$null; filesChanged="" }
            }
            $i++
        }
        $run.tasks = $tasks
        Add-CicadaEvent -Run $run -Type "plan" -Data ([string]::Join(" | ", @($tasks | ForEach-Object { $_.title })))
        Save-CicadaRun -Run $run
        Stamp ("PLAN: enforcement split it into " + $tasks.Count + " tasks")
    } else {
        Stamp "PLAN: enforcement returned one task - proceeding (continuation machinery covers it)"
    }
}
    Stamp "PLAN: $($tasks.Count) tasks queued"
}

# ---------- BUILD / VALIDATE / REVIEW loop ----------

:taskLoop foreach ($task in $run.tasks) {
    if ($task.status -eq "done") { continue }
# STRICT SEQUENCE: do not build task N+1 while any earlier task is blocked.
# The blocked task has already been rolled back or will be handled by its
# normal branch; remaining tasks stay pending for a focused re-plan/resume.
$blockedTasks = @($run.tasks | Where-Object { $_.status -eq "blocked" })
if ($blockedTasks.Count -gt 0) {
    $firstBlocked = $blockedTasks | Sort-Object n | Select-Object -First 1
    Stamp ("RUN PAUSED: task " + $firstBlocked.n + " is blocked; leaving later tasks pending for correction/re-plan")
    Add-CicadaEvent -Run $run -Type "sequence_pause" -Data ("blocked task " + $firstBlocked.n + "; later tasks not started")
    Save-CicadaRun -Run $run
    break taskLoop
}
    while ($task.status -in @("pending","retry")) {
        if ($run.totals.calls -ge $MaxCalls) {
            $task.status = "blocked"; $task.verdict = "call budget exhausted"
            Add-CicadaEvent -Run $run -Type "budget_stop" -Data "task $($task.n)"
            Save-CicadaRun -Run $run
            continue taskLoop
        }
        if ($MaxTokens -gt 0 -and [int64]$run.totals.tokens -ge $MaxTokens) {
            $task.status = "blocked"; $task.verdict = "token budget exhausted"
            Add-CicadaEvent -Run $run -Type "budget_stop" -Data "task $($task.n) at $($run.totals.tokens) tokens"
            Save-CicadaRun -Run $run
            continue taskLoop
        }
        if ($MaxCost -gt 0 -and [double]$run.totals.cost -ge $MaxCost) {
            $task.status = "blocked"; $task.verdict = "cost budget exhausted"
            Add-CicadaEvent -Run $run -Type "budget_stop" -Data "task $($task.n) at `$$($run.totals.cost)"
            Save-CicadaRun -Run $run
            continue taskLoop
        }

        # BUILD
        # INTERRUPT: operator steering - picked up between attempts, routed through the planner (never raw to the builder)
        $irq = Read-CicadaInterrupt
        if (-not $irq -and (Get-Command Get-CicadaSteeringFor -ErrorAction SilentlyContinue)) { $irq = Get-CicadaSteeringFor $runName; if ($irq) { Stamp ("STEER task " + $task.n + ": note for " + $runName + " picked up") } }
        if ($irq) {
            Stamp ("INTERRUPT task " + $task.n + ": operator note received - consulting the planner")
            $iArgs = @{ Project=$Project; Model=$PlanModel; Agent=$PlanAgent; Title=($run.id + "-t" + $task.n + "-irq" + $task.attempts) }
            $iArgs.Prompt = "The operator of this autonomous coding system interrupted the run with a steering note. Objective: " + $Objective + "`nCurrent task " + $task.n + ": " + $task.title + "`nTask status: " + $task.status + "; attempts so far: " + $task.attempts + "; last verdict: " + $task.verdict + "`nOperator note: " + $irq + "`nThe operator is speaking to YOU, the planner - not the builder. Decide what the builder should be told on the next attempt: what to do, what to stop doing, what it should stop being told. Respond with exactly one line: GUIDANCE: <instruction for the builder> | REVISED TASK: <replacement task title> | FATAL: <why this cannot be done>"
            if ($planSession) { $iArgs.SessionId = $planSession }
            $ir = Invoke-Supervised -CallArgs $iArgs -TimeoutSec $CallTimeoutSec
            Add-Totals $ir
            $iline = ""
            if ($ir.Text) { $iline = (($ir.Text -split "`n") | Select-Object -First 1).Trim() }
            Add-CicadaEvent -Run $run -Type "interrupt" -Data ("task " + $task.n + ": operator said: " + $irq + " | planner replied: " + $iline)
            if ($iline) {
                $prior = ""
                if ($task.verdict) { $prior = " | prior feedback: " + $task.verdict }
                if ($iline -match "^FATAL:?\s*(.*)$") { $task.status = "blocked"; $task.verdict = "operator interrupt -> planner FATAL: " + $Matches[1].Trim() }
                else {
                    if ($iline -match "^REVISED TASK:?\s*(.*)$") { $task.title = $Matches[1].Trim(); $task.verdict = "task revised after operator interrupt" + $prior; Stamp ("INTERRUPT task " + $task.n + ": planner revised the task") }
                    elseif ($iline -match "^GUIDANCE:?\s*(.*)$") { $task.verdict = "operator steering via planner: " + $Matches[1].Trim() + $prior }
                    else { $task.verdict = "operator steering via planner: " + $iline + $prior }
                    if ($task.status -eq "pending") { $task.status = "retry" }
                }
                Save-CicadaRun -Run $run
                Stamp ("INTERRUPT task " + $task.n + ": planner guidance applied to the next attempt")
            } else {
                Stamp ("INTERRUPT task " + $task.n + ": planner returned nothing - continuing unchanged")
            }
        }
        $task.attempts++
        $task.status = "building"
        Save-CicadaRun -Run $run
        Stamp "BUILD task $($task.n) attempt $($task.attempts): $($task.title)"
        $buildArgs = @{
            Project = $Project
            Prompt  = Get-BuildPrompt -Task $task.title -FilesHint ($task.files -join ", ") -ValidateHint $task.validate -Attempt $task.attempts -Previous $task.verdict
            Model   = $BuilderModel
            Agent   = $BuilderAgent
            Title   = "$($run.id)-t$($task.n)-a$($task.attempts)"
        }
        $buildArgs.Prompt += " VALIDATION RULE for your VALIDATION line: the gate runs it and checks the exit code (0 = pass). findstr exits 0 when text is FOUND and 1 when ABSENT - for must-be-absent checks write a powershell -NoProfile -Command -notmatch test that exits 0 only when the text is gone. Presence checks stay simple."
        if ($task.session) { $buildArgs.SessionId = $task.session }
        $b = Invoke-Supervised -CallArgs $buildArgs -TimeoutSec $CallTimeoutSec
        Add-Totals $b
        if ($b.SessionId) { $task.session = $b.SessionId }
        $task.report = $b.Text
        $rep = Read-BuildReport $b.Text
        if ($rep.files) { $task.filesChanged = $rep.files }
        Add-CicadaEvent -Run $run -Type "build_result" -Data "task $($task.n) attempt $($task.attempts) exit=$($b.ExitCode) err=$($b.ErrorName) cost=$($b.Cost)"

        $builderOk = ($b.ExitCode -eq 0) -and $rep.complete
        if (-not $builderOk) {
            $reason = "builder failed (exit $($b.ExitCode))"
            if ($rep.blocked) { $reason = "builder blocked: $($rep.blockReason)" }
            if ($rep.blocked -and $planSession -and $task.attempts -le $MaxTaskRetries) {
                Stamp ("CONSULT task " + $task.n + ": builder blocked - asking the planner")
                $cPrompt = "The builder is blocked on task $($task.n) ('$($task.title)'): $($rep.blockReason). The builder has only read/edit/bash tools, no network, no credentials. Respond with exactly one line: GUIDANCE: <one-sentence instruction that unblocks it> | REVISED TASK: <replacement task title> | FATAL: <why this cannot be done>"
                $cr = Invoke-Supervised -CallArgs @{ Project=$Project; Prompt=$cPrompt; Model=$PlanModel; Agent=$PlanAgent; SessionId=$planSession; Title=("$($run.id)-t$($task.n)-c$($task.attempts)") } -TimeoutSec $CallTimeoutSec
                Add-Totals $cr
                $cline = ""
                if ($cr.Text) { $cline = (($cr.Text -split "`n") | Select-Object -First 1).Trim() }
                Add-CicadaEvent -Run $run -Type "consult" -Data ("task $($task.n): planner replied: " + $cline)
                if ($cline) {
                    if ($cline -match "^FATAL:?\s*(.*)$") { $task.status = "blocked"; $task.verdict = "planner FATAL: " + $Matches[1].Trim() }
                    else {
                        if ($cline -match "^REVISED TASK:?\s*(.*)$") { $task.title = $Matches[1].Trim(); $task.verdict = "task revised by planner: " + $task.title; Stamp ("CONSULT task " + $task.n + ": planner revised the task") }
                        elseif ($cline -match "^GUIDANCE:?\s*(.*)$") { $task.verdict = "planner guidance: " + $Matches[1].Trim() }
                        else { $task.verdict = $reason + " | planner: " + $cline }
                        $task.status = "retry"
                    }
                    Add-CicadaEvent -Run $run -Type "verdict" -Data "task $($task.n): $($task.status) - $($task.verdict)"
                    Save-CicadaRun -Run $run
                    continue
                }
            }
            elseif ($b.ErrorMessage) { $reason = $b.ErrorMessage }
            $continued = $false
            if (-not $rep.blocked) {
                $stepsUsed = 0
                if ($b.LogPath -and (Test-Path $b.LogPath)) { $stepsUsed = ([regex]::Matches((Get-Content $b.LogPath -Raw), '"type":"step_start"')).Count }
                if ($stepsUsed -ge 55) {
                    $continued = $true
                    $reason = "step budget exhausted at $stepsUsed steps - CONTINUATION: the files on disk hold the work so far; do not restart or re-read everything, finish the remaining work, then emit the report"
                    Stamp ("BUILD task " + $task.n + ": step budget exhausted (" + $stepsUsed + ") - continuing same session")
                }
            }
            if ($task.attempts -gt $MaxTaskRetries) { $task.status = "blocked"; $task.verdict = $reason }
            else { $task.status = "retry"; $task.verdict = $reason }
            if (-not $continued) { $task.session = $null }
            Add-CicadaEvent -Run $run -Type "verdict" -Data "task $($task.n): $($task.status) - $reason"
            Save-CicadaRun -Run $run
            continue
        }

        # VALIDATE (deterministic, no model). Gate authority: the plan's "validate"
        # command is the spec; the builder's VALIDATION line is only a fallback, so
        # the implementer never grades its own homework.
        $valEvidence = "Builder self-report: $($rep.result)"
        $gatePass = $null
        $gateCmd = $rep.validation
        if ($task.validate -and $task.validate.Trim()) { $gateCmd = $task.validate.Trim() }
        if ($gateCmd -match "^\s*type\s+(.+?)\s*$") { $typeArgs = $Matches[1] } else { $typeArgs = $null }
        if ($typeArgs -and $typeArgs -match "\btype\b") {
            $normFiles = ($typeArgs -split "\s+" | Where-Object { $_ -ne "type" }) -join ","
            $gateCmd = "type $normFiles"
            Stamp ("VALIDATE task " + $task.n + ": normalized mangled command -> " + $gateCmd)
        }
        if ($gateCmd) {
            Stamp "VALIDATE task $($task.n): $gateCmd"
            $gateCmds = @($gateCmd)
            $kwHits = [regex]::Matches($gateCmd, '(?:(?<=^)|(?<=[^|\s]\s+))(findstr|type|powershell|node|npm|python)(?=\s|\.|$)')
            if ($kwHits.Count -gt 1) { $gateCmds = @(); for ($k = 0; $k -lt $kwHits.Count; $k++) { $segStart = $kwHits[$k].Index; $segEnd = $gateCmd.Length; if ($k + 1 -lt $kwHits.Count) { $segEnd = $kwHits[$k + 1].Index }; $gateCmds += $gateCmd.Substring($segStart, $segEnd - $segStart).Trim() } }
            if ($gateCmds.Count -gt 1) { Stamp ("VALIDATE task " + $task.n + ": split mangled multi-command into " + $gateCmds.Count + " checks: " + ($gateCmds -join "  |  ")) }
            $engineSegs = @(Split-CicadaGateCommand $gateCmd)
            if ($engineSegs.Count -gt $gateCmds.Count) { $gateCmds = $engineSegs; Stamp ("VALIDATE task " + $task.n + ": splitter recovered " + $engineSegs.Count + " checks") }
            $gateCmds = @(Normalize-CicadaGateCommands $gateCmds)
            $vres = @{ code = 0; output = "" }
            foreach ($gcmd in $gateCmds) { $vres = Invoke-Validation $gcmd; if ($vres.code -ne 0) { Stamp ("VALIDATE task " + $task.n + ": check failed -> " + $gcmd + " (exit " + $vres.code + ")"); $script:CicadaLastGateFail = $gcmd; break } }
            $gatePass = ($vres.code -eq 0)
            $valEvidence = "Orchestrator re-ran: $gateCmd | exit $($vres.code) | output tail: $(Get-Tail $vres.output 400)"
            Add-CicadaEvent -Run $run -Type "validation" -Data "task $($task.n): '$gateCmd' exit=$($vres.code)"
            Save-CicadaRun -Run $run
            if (-not $gatePass) {
                $reason = "validation failed on check [" + $gcmd + "] (exit " + $vres.code + "): " + (Get-Tail $vres.output 300) + " - that named check is the FIRST failure; fix exactly that: confirm the file path exists and the exact string is present, and re-run this check yourself before reporting COMPLETE."
$corrPrompt = "A builder's work failed its validation gate. Task: " + $task.title + " Failing check: " + $gcmd + " Gate output tail: " + (Get-Tail $vres.output 300) + " Write the minimal correction plan: 1-3 short imperatives the builder should execute on the next attempt. No preamble."
$cr = Invoke-Supervised -CallArgs @{ Project=$Project; Prompt=$corrPrompt; Model=$PlanModel; Agent=$PlanAgent; Title=($run.id + "-corr-" + $task.n + "-a" + $task.attempts) } -TimeoutSec 300
Add-Totals $cr
if ($cr.ExitCode -eq 0 -and $cr.Text) { $reason = $reason + " Correction plan: " + (($cr.Text -replace "\s+", " ").Trim()) }
                if ($task.attempts -gt $MaxTaskRetries) { $task.status = "blocked"; $task.verdict = $reason }
                else { $task.status = "retry"; $task.verdict = $reason }
                Add-CicadaEvent -Run $run -Type "verdict" -Data "task $($task.n): $($task.status) - validation gate"
                Save-CicadaRun -Run $run
                Stamp "VALIDATE task $($task.n): FAILED -> $($task.status)"
                continue
            }
            Stamp "VALIDATE task $($task.n): PASS"
        }

        # AUTO-ACCEPT: mechanical proof + low risk -> no review call
        if ($gateCmd -and $gatePass -and $task.risk -ne "high") {
            $task.status = "done"; $task.verdict = "NEXT (auto-verified)"
            Add-CicadaEvent -Run $run -Type "verdict" -Data "task $($task.n): done - auto-verified"
            Save-CicadaRun -Run $run
            Stamp "VERDICT task $($task.n): done - auto-verified"
            continue
        }

        # REVIEW (high-risk, or no mechanical validation exists)
        $task.status = "review"
        Save-CicadaRun -Run $run
        Stamp "REVIEW task $($task.n)"
        $v = Invoke-Supervised -CallArgs @{ Project=$Project; Prompt=(Get-ReviewPrompt -Task $task.title -Attempt $task.attempts -Report $b.Text -ValEvidence $valEvidence); Model=$ReviewModel; Agent=$ReviewAgent; Title="$($run.id)-t$($task.n)-r$($task.attempts)" } -TimeoutSec $CallTimeoutSec
        Add-Totals $v
        $line = ""
        if ($v.Text) { $line = (($v.Text -split "`n") | Select-Object -First 1).Trim() }

        if ($line -match "^NEXT") {
            $task.status = "done"; $task.verdict = "NEXT"
        }
        elseif ($line -match "^BLOCKED:?\s*(.*)$") {
            $task.status = "blocked"; $task.verdict = $Matches[1].Trim()
        }
        else {
            $why = "reviewer requested retry"
            if ($line -match "^RETRY:?\s*(.*)$") { $why = $Matches[1].Trim() }
            if ($task.attempts -gt $MaxTaskRetries) { $task.status = "blocked"; $task.verdict = $why }
            else { $task.status = "retry"; $task.verdict = $why }
        }
        Add-CicadaEvent -Run $run -Type "verdict" -Data "task $($task.n): $($task.status) - $($task.verdict)"
        Save-CicadaRun -Run $run
        Stamp "VERDICT task $($task.n): $($task.status) - $($task.verdict)"
    }

    # ---------- git checkpoint / rollback ----------
    if ($gitOn) {
        if ($task.status -eq "done") {
            $pending = & git -C $Project status --porcelain 2>&1 | Out-String
            if ($pending.Trim()) {
                & git -C $Project add -A 2>&1 | Out-Null
                $cTitle = [string]$task.title; if ($cTitle.Length -gt 60) { $cTitle = $cTitle.Substring(0,60) }
                & git -C $Project commit -m ("cicada: task " + $task.n + " - " + $cTitle) --quiet 2>&1 | Out-Null
                $sha = (& git -C $Project rev-parse --short HEAD 2>&1 | Out-String).Trim()
                Add-CicadaEvent -Run $run -Type "commit" -Data "task $($task.n): $sha $($task.title)"
                Save-CicadaRun -Run $run
                Stamp "COMMIT task $($task.n): $sha"
            }
        }
        elseif ($task.status -eq "blocked") {
            & git -C $Project checkout -- . 2>&1 | Out-Null
            & git -C $Project clean -fd 2>&1 | Out-Null
            Add-CicadaEvent -Run $run -Type "rollback" -Data "task $($task.n): uncommitted changes discarded"
            Save-CicadaRun -Run $run
            Stamp "ROLLBACK task $($task.n)"
            Send-CicadaTelegram ("CICADA [" + $ModeLabel + "] task BLOCKED | " + (Split-Path -Leaf $Project) + " | task " + $task.n + ": " + $task.title + " | " + $task.verdict)
        }
    }
}

# ---------- run end ----------

$done    = @($run.tasks | Where-Object status -eq "done").Count
$blocked = @($run.tasks | Where-Object status -eq "blocked").Count
if ($blocked -eq 0)   { $run.status = "complete" }
elseif ($done -gt 0)  { $run.status = "complete_with_blocked" }
else                  { $run.status = "blocked" }

# ---------- digest ----------

function Write-Digest {
    $dir = Join-Path (Split-Path -Parent $PSScriptRoot) "state\runs"
    $path = Join-Path $dir ($run.id + "-digest.md")
    $dur = ""
    try { $d = [DateTime]::Parse($run.updated) - [DateTime]::Parse($run.created); $dur = $d.ToString("hh\:mm\:ss") } catch { }
    $lines = @()
    $lines += "# CICADA run digest"
    $lines += ""
    $lines += "- Run:       $($run.id)"
    $lines += "- Project:   $($run.project)"
    $lines += "- Objective: $($run.objective)"
    $lines += "- Status:    $($run.status)"
    $lines += "- Duration:  $dur"
    $lines += "- Calls:     $($run.totals.calls) | Tokens: $($run.totals.tokens) | Cost: `$$([math]::Round([double]$run.totals.cost,5))"
    $lines += ""
    $lines += "## Tasks"
    $lines += ""
    $lines += "| # | Task | Status | Attempts | Verdict | Files |"
    $lines += "|---|------|--------|----------|---------|-------|"
    foreach ($t in $run.tasks) {
        $lines += "| $($t.n) | $(ConvertTo-Cell $t.title) | $($t.status) | $($t.attempts) | $(ConvertTo-Cell $t.verdict) | $(ConvertTo-Cell $t.filesChanged) |"
    }
    if ($gitOn -and $run.git) {
        $log = (& git -C $Project log --oneline ($run.git.baseline + "..HEAD") 2>&1 | Out-String).Trim()
        $diff = (& git -C $Project diff --stat ($run.git.baseline + "..HEAD") 2>&1 | Out-String).Trim()
        $lines += ""
        $lines += "## Git"
        $lines += ""
        $lines += "Baseline: $($run.git.baseline)"
        $lines += ""
        $lines += '```'
        if ($log) { $lines += $log } else { $lines += "(no task commits)" }
        $lines += '```'
        $lines += ""
        $lines += '```'
        if ($diff) { $lines += $diff } else { $lines += "(no net changes)" }
        $lines += '```'
    }
    ($lines -join "`n") | Set-Content -Path $path -Encoding utf8
    return $path
}

$digestPath = Write-Digest
Add-CicadaEvent -Run $run -Type "digest" -Data $digestPath
Add-CicadaEvent -Run $run -Type "run_end" -Data "status=$($run.status) done=$done blocked=$blocked calls=$($run.totals.calls) cost=$([math]::Round($run.totals.cost,5))"
Save-CicadaRun -Run $run

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " RUN $($run.status.ToUpper())" -ForegroundColor $(if ($run.status -eq "complete") { "Green" } else { "Yellow" })
Write-Host " Tasks:   $done done, $blocked blocked (of $(@($run.tasks).Count))"
Write-Host " Calls:   $($run.totals.calls)"
Write-Host " Tokens:  $($run.totals.tokens)"
Write-Host " Cost:    `$$([math]::Round($run.totals.cost,5))"
Write-Host " Journal: state\runs\$($run.id).json"
Write-Host " Digest:  state\runs\$($run.id)-digest.md"
Write-Host "========================================" -ForegroundColor Cyan

if ($run.status -eq "complete") { exit 0 } else { exit 2 }





